function _HostClass(hostType) {
    return class {
        constructor() {
            let target = new hostType();
            Object.defineProperty(this, 'clrSuper', { value: target });
            Object.setPrototypeOf(
                this,
                new Proxy(
                    Object.getPrototypeOf(this),
                    {
                        has: (proto, key) => key in proto || key in target,
                        get: (proto, key) => key in proto ? proto[key] : target[key],
                        set: (obj, key, value) => {
                            if (key in target)
                                return Reflect.set(target, key, value)
                            else
                                return Reflect.set(obj, key, value)
                        }
                    }));
        }
    };
}

function _ToClrArray(type, array) {
    var clrArray = host.newArr(type, array.length);
    for (var i = 0; i < array.length; ++i) {
        clrArray[i] = array[i];
    }
    return clrArray;
};