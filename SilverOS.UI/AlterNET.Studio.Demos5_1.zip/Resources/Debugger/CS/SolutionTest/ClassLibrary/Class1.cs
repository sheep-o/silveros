using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 
using System.Threading.Tasks;

namespace ClassLibrary    
{ 
    public class Class1 
    {
        public Class1()
        {
            HelloMessage = "Hi World!";
        } 

        public string HelloMessage { get; set; }
    }
}
