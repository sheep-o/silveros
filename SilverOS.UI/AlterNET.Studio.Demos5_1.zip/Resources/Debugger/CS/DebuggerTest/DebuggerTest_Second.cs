using System;

namespace DebuggerTest
{
	class SecondClass
	{
		public static int Func()
		{
			return 10;
		}
	}
}
