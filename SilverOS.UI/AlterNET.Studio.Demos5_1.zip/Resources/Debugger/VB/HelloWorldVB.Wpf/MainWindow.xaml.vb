﻿Class MainWindow 

    Private Sub Window_Loaded(sender As Object, e As RoutedEventArgs)
        MessageBox.Show("Loaded")
    End Sub
End Class
