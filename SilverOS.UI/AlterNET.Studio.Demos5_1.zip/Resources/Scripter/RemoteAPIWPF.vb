﻿Imports System
Imports System.Collections
Imports System.Runtime.Remoting
Imports System.Runtime.Remoting.Channels
Imports System.Runtime.Remoting.Channels.Ipc
Imports System.Runtime.Serialization.Formatters

Namespace DebugRemoteScript.Wpf
    Interface IScriptAPI
        Function GetEditorText() As String
        Sub ShowMessage(ByVal text As String)
    End Interface

    Public Class RemoteAPI
        Private Const DefaultIpcObjectUri As String = "ScriptDebuggerRemoteControl"
        Private Const DefaultIpcPortName As String = "ScriptDebuggerIpcServer"
        Private Const DefaultIpcClientChannel As String = "ClientChannel"
        Private Shared scriptAPI As IScriptAPI

        Public Class ScriptAPI
            Inherits MarshalByRefObject
            Implements IScriptAPI

            Public Function GetEditorText() As String
                Return scriptAPI.GetEditorText()
            End Function

            Public Sub ShowMessage(ByVal text As String)
                scriptAPI.ShowMessage(text)
            End Sub
        End Class

        Public Shared Function StartClient(ByVal Optional ipcPortName As String = Nothing, ByVal Optional ipcObjectUri As String = Nothing, ByVal Optional ipcClientChannel As String = Nothing) As IScriptAPI
            Dim properties = New Hashtable()
            properties("portName") = If(ipcClientChannel, DefaultIpcClientChannel)
            properties("typeFilterLevel") = TypeFilterLevel.Full
            Return CType(Activator.GetObject(GetType(IScriptAPI), String.Format("ipc://{0}/{1}", If(ipcPortName, DefaultIpcPortName), If(ipcObjectUri, DefaultIpcObjectUri))), IScriptAPI)
        End Function

        Public Shared Function StartServer(ByVal api As IScriptAPI, ByVal Optional ipcPortName As String = Nothing, ByVal Optional ipcObjectUri As String = Nothing) As IChannel
            scriptAPI = api
            Dim properties = New Hashtable()
            properties("portName") = If(ipcPortName, DefaultIpcPortName)
            properties("typeFilterLevel") = TypeFilterLevel.Full
            Dim channel = New IpcChannel(properties, Nothing, New BinaryServerFormatterSinkProvider With {
                .TypeFilterLevel = TypeFilterLevel.Full
            })
            ChannelServices.RegisterChannel(channel, False)
            RemotingConfiguration.RegisterWellKnownServiceType(GetType(ScriptAPI), If(ipcObjectUri, DefaultIpcObjectUri), WellKnownObjectMode.Singleton)
            Return channel
        End Function
    End Class
End Namespace
