Imports System
Imports System.Runtime.InteropServices

Namespace DebugRemoteScript
    Public Class Program
        Private Shared Function InitializeRemoting(ByVal ipcPortName As String, ByVal ipcObjectUri As String) As IScriptAPI
            Return RemoteAPI.StartClient(If(Not String.IsNullOrEmpty(ipcPortName), ipcPortName, Nothing), If(Not String.IsNullOrEmpty(ipcObjectUri), ipcObjectUri, Nothing), If(Not String.IsNullOrEmpty(ipcPortName), ipcPortName & "ClientChannel", Nothing))
        End Function

        Private Shared Function ExtractCommandLineArg(ByVal arg As String) As String
            Dim idx As Integer = arg.IndexOf("=")
            Return If(idx >= 0, arg.Substring(idx + 1), arg)
        End Function

        Private Shared Sub ParseCommandLineArgs(ByVal args As String(), ByRef ipcPortName As String, ByRef ipcObjectUri As String)
            ipcPortName = Nothing
            ipcObjectUri = Nothing

            For Each arg As String In args
                Dim larg As String = arg.ToLower()

                If larg.StartsWith("-ipcportname=") Then
                    ipcPortName = ExtractCommandLineArg(arg)
                ElseIf larg.StartsWith("-ipcobjecturi=") Then
                    ipcObjectUri = ExtractCommandLineArg(arg)
                End If
            Next
        End Sub

        <STAThread>
        Public Shared Sub Main(ByVal args As String())
            Dim ipcPortName As String
            Dim ipcObjectUri As String
            ParseCommandLineArgs(args, ipcPortName, ipcObjectUri)
            Dim remote = InitializeRemoting(ipcPortName, ipcObjectUri)
            Dim text = remote.GetEditorText()
            Dim str = String.Empty

            For Each c In text
                str = c + str
            Next

            remote.ShowMessage(str)
        End Sub
    End Class
End Namespace
