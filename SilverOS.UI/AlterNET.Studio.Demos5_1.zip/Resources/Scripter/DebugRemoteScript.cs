using System; 

namespace DebugRemoteScript
{
	public class Program
	{
		static IScriptAPI InitializeRemoting(string ipcPortName, string ipcObjectUri)
		{
			return RemoteAPI.StartClient(!string.IsNullOrEmpty(ipcPortName) ? ipcPortName : null, !string.IsNullOrEmpty(ipcObjectUri) ? ipcObjectUri : null, !string.IsNullOrEmpty(ipcPortName) ? ipcPortName + "ClientChannel" : null);
		}

		static string ExtractCommandLineArg(string arg)
		{
			int idx = arg.IndexOf("=");
			return idx >= 0 ? arg.Substring(idx + 1) : arg;
		}

		static void ParseCommandLineArgs(string[] args, out string ipcPortName, out string ipcObjectUri)
		{
			ipcPortName = null;
			ipcObjectUri = null;
			foreach (string arg in args)
			{
				string larg = arg.ToLower();
				if (larg.StartsWith("-ipcportname="))
					ipcPortName = ExtractCommandLineArg(arg);
				else
				if (larg.StartsWith("-ipcobjecturi="))
					ipcObjectUri = ExtractCommandLineArg(arg);
			}
		}

		[STAThread]
		public static void Main(string[] args)
		{
			string ipcPortName;
			string ipcObjectUri;
			ParseCommandLineArgs(args, out ipcPortName, out ipcObjectUri);
			var remote = InitializeRemoting(ipcPortName, ipcObjectUri);
			var text = remote.GetEditorText();
			var str = string.Empty;
			foreach (var c in text)
			{
				str = c + str;
			}
			remote.ShowMessage(str);
		}
	}
}