function secondFunction(x: number): string
{
    return x + "";
}