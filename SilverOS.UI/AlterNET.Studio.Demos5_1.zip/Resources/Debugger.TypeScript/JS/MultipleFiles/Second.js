function secondFunction(x)
{
    return x + "";
}
