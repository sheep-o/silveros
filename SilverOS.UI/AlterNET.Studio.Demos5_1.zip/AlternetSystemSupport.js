function _HostClass(hostType) {
    return /** @class */ (function () {
        function class_1() {
            var target = new hostType();
            Object.defineProperty(this, 'clrSuper', { value: target });
            Object.setPrototypeOf(this, new Proxy(Object.getPrototypeOf(this), {
                has: function (proto, key) { return key in proto || key in target; },
                get: function (proto, key) { return key in proto ? proto[key] : target[key]; },
                set: function (obj, key, value) {
                    if (key in target)
                        return Reflect.set(target, key, value);
                    else
                        return Reflect.set(obj, key, value);
                }
            }));
        }
        return class_1;
    }());
}
function _ToClrArray(type, array) {
    var clrArray = host.newArr(type, array.length);
    for (var i = 0; i < array.length; ++i) {
        clrArray[i] = array[i];
    }
    return clrArray;
}
;
//# sourceMappingURL=AlternetSystemSupport.js.map